import React, { useState } from "react";

function App() {
  const [h1text, seth1text] = useState("");
  const [h1text2, seth1text2] = useState(h1text);

  function updateH1(event) {
    // console.log(event.target.placeholder);
    console.log(event.target.value);
    seth1text(event.target.value);
    // console.log(h1text);
  }

  function updateH12(event) {
    seth1text2(h1text);
    event.preventDefault();
  }

  return (
    <div className="container">
      <h1>Hello {h1text2}</h1>
      <form action="">
        <input
          onChange={updateH1}
          type="text"
          placeholder="What's your name?"
        />
        <button onClick={updateH12}>Submit</button>
      </form>
    </div>
  );
}

export default App;
